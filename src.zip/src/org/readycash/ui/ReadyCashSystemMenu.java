package org.readycash.ui;

import javax.microedition.pim.Contact;

import org.readycash.core.StoreManager;
import org.readycash.ui.screens.SendMoneyScreen;

import net.rim.blackberry.api.menuitem.ApplicationMenuItem;
import net.rim.device.api.ui.UiApplication;
import net.rim.device.api.ui.component.Dialog;

public class ReadyCashSystemMenu extends ApplicationMenuItem {

	public ReadyCashSystemMenu(int order) {
		super(20);
	}

	// TODO Auto-generated constructor stub}

	public ReadyCashSystemMenu() {
		this(0);
		// TODO Auto-generated constructor stub
	}

	public Object run(Object context) {
		Contact recipient;
		// Dialog.alert("Sending Money");
		// return null;
		if (context instanceof Contact) {
			recipient = (Contact) context;
			if (0 < recipient.countValues(Contact.TEL)) {
				String phone = recipient.getString(Contact.TEL, 0);
				if (StoreManager.getRegisteredStatus().booleanValue()
						&& StoreManager.getVerifiedStatus().booleanValue()) {
					UiApplication.getUiApplication().pushScreen(
							new SendMoneyScreen(phone));
				} else {
					Dialog.alert("You would need to register or verify first");
				}

			} else {
				Dialog.alert("No Phone number for contact");
			}
		}
		return null;
	}

	public String toString() {
		return "Send Money With ReadyCash";
	}

}
