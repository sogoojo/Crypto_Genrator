package org.readycash.ui.screens;

import javax.microedition.global.Formatter;

import org.readycash.core.Security;
import org.readycash.core.StoreManager;


import net.rim.device.api.ui.UiApplication;
import net.rim.device.api.ui.component.LabelField;
import com.blackberry.toolkit.ui.component.BorderedEditField;


public class WithdrawScreen extends AppScreen {

	BorderedEditField bAgentId;

	public WithdrawScreen() {
		// TODO Auto-generated constructor stub

		super();
		setTitle("Withdraw Funds From Agent");
		setupAccountNumber(cv);
		cv.add(new LabelField("Agent Id: "));
		bAgentId = new BorderedEditField();
		cv.add(bAgentId);

		setupAmount(cv);
		setupPIN(cv);

		fm.add(cv);
		setupActionButton(fm, "Withdraw", "", this);

		add(fm);
	}

	public final String getActivityTitle() {
		return "withdraw funds";
	}

	public final String getSummary() {
		StringBuffer sb = new StringBuffer();
		sb.append("You are about to withdraw \n");
		double amt = Double.parseDouble(bAmount.getText());
		sb.append("NGN " + amt + "\n");
		sb.append("from Agent : " + bAgentId.getText());
		return sb.toString();
	}

	public void handleResponse(Object responseData) {
		// TODO Auto-generated method stub
		
		UiApplication.getUiApplication().popScreen(this);
		
	}
	
	
	public boolean onClose() {
		// TODO Auto-generated method stub
		clearFields();
		setDirty(false);
		return super.onClose();
	}

	
	protected void clearFields() {
		// TODO Auto-generated method stub
		bAgentId.setText("");
		bAmount.setText("");
		pPIN.setText("");
		
	}

	public String getAction() {
		String encPIN = Security.encrypt(Security.KEY_USER, pPIN.getText());			
		String data = StoreManager.getPhoneNumber()+"/"+encPIN + "/" + bAgentId.getText() + "/" +bAmount.getText();
		data = Security.encrypt(Security.KEY_USER,data);
		return "X/AW/"  + data;
	}

	
}
