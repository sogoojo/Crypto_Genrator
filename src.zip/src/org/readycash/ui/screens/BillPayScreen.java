package org.readycash.ui.screens;

import javax.microedition.lcdui.Graphics;

import org.readycash.core.FieldValidator;
import org.readycash.core.Security;
import org.readycash.core.StoreManager;

import com.blackberry.toolkit.ui.component.BorderedEditField;

import net.rim.device.api.ui.Color;
import net.rim.device.api.ui.UiApplication;
import net.rim.device.api.ui.component.LabelField;

public class BillPayScreen extends AppScreen {

	private String code = null;
	private BorderedEditField bMerchant;
	private BorderedEditField bId;
	private String id;

	public BillPayScreen(String code, String id, long idType) {
		// TODO Auto-generated constructor stub
		super();
		bMerchant = new BorderedEditField();
		this.id = id;
		this.code = code;
		setTitle("Pay " + code);
		setupAccountNumber(cv);
		if (code == null) {

			cv.add(new LabelField("Merchant Code:"));

			cv.add(bMerchant);
			cv.add(new LabelField("Customer Id"));
		} else {
			cv.add(new LabelField("Merchant"));
			LabelField lf = new LabelField(code) {
				protected void paint(net.rim.device.api.ui.Graphics graphics) {

					graphics.setColor(Color.STEELBLUE);
					super.paint(graphics);
				};
			};

			lf.setMargin(5, 5, 10, 10);
			cv.add(lf);
			cv.add(new LabelField(id));
		}
		bId = new BorderedEditField("", "", 30, idType);
		cv.add(bId);
		setupAmount(cv);
		setupPIN(cv);
		fm.add(cv);
		String payee = code == null ? "" : code;
		setupActionButton(fm, "Pay " + payee, getAction(), this, false);
		add(fm);

	}

	public boolean isDataValid() {
		String label = id == null ? "Customer Id" : id;
		fv.checkExists(label, bId);
		if(code == null)
			fv.checkExists("Merchant", bMerchant);
		return super.isDataValid();
	}

	protected void clearFields() {
		bAmount.setText("");
		bMerchant.setText("");
		pPIN.setText("");
		bId.setText("");

	}

	public boolean onClose() {
		// TODO Auto-generated method stub
		clearFields();
		setDirty(false);
		return super.onClose();
	}

	public String getAction() {
		String encPIN = Security.encrypt(Security.KEY_USER, pPIN.getText());
		String payee = code == null ? bMerchant.getText() : code;
		String data = StoreManager.getPhoneNumber() + "/" + encPIN + "/" + payee
				+ "/" + "/" + bId.getText() + bAmount.getText();
		data = Security.encrypt(Security.KEY_USER, data);
		return "X/PB/" + data;
	}

	public String getActivityTitle() {
		// TODO Auto-generated method stub
		String payee =  code == null ? bMerchant.getText() : code;
		return payee + " Payment";
	}

	public String getSummary() {
		StringBuffer sb = new StringBuffer();
		sb.append("You are about to pay \n");
		double amt = Double.parseDouble(bAmount.getText());
		sb.append("NGN " + amt);
		sb.append(" to : \n");
		sb.append(code != null ? code : bMerchant.getText());
		return sb.toString();
	}

	public void handleResponse(Object responseData) {
		// TODO Auto-generated method stub
		clearFields();
		UiApplication.getUiApplication().popScreen(this);
	}

}
