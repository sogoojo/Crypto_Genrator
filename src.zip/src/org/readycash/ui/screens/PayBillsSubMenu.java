package org.readycash.ui.screens;

import net.rim.device.api.ui.component.EditField;
import net.rim.device.api.ui.component.LabelField;
import net.rim.device.api.ui.component.NullField;

import org.readycash.core.PushScreenEventListener;

import com.blackberry.toolkit.ui.container.ListStyleButtonSet;

public class PayBillsSubMenu extends AppScreen {

	public PayBillsSubMenu() {
		
		super();
		setTitle("Select Biller");
		fm.add(new LabelField("Cable TV"));
		ListStyleButtonSet set = new ListStyleButtonSet();
		String[] cable =  {"Dstv", "HiTv","NTA/StarTimes","DaarSat"};
		for (int i =0 ; i < cable.length; i++)
		{
			set.addCustom(null, _caret, cable[i]).setChangeListener(
					new PushScreenEventListener(new BillPayScreen(cable[i],"SmartCard #",EditField.FILTER_NUMERIC)));
		}
		set.setMargin(15, 15, 15, 15);
		fm.add(set);
		fm.add(new LabelField("Pensions"));
		set = new ListStyleButtonSet();
		String[] pension =  {"First Guarantee", "UBA Pensions"};
		for (int i =0 ; i < pension.length; i++)
		{
			set.addCustom(null, _caret, pension[i]).setChangeListener(
					new PushScreenEventListener(new BillPayScreen(pension[i],"RSA #",EditField.FILTER_NUMERIC)));
		}
		set.setMargin(15, 15, 15, 15);
		fm.add(set);
		fm.add(new LabelField("Insurance"));		
		set = new ListStyleButtonSet();
		String[] insurance =  {"IFA", "Standard Alliance"};
		for (int i =0 ; i < insurance.length; i++)
		{
			set.addCustom(null, _caret, insurance[i]).setChangeListener(
					new PushScreenEventListener(new BillPayScreen(insurance[i],"Customer #",EditField.FILTER_NUMERIC)));
		}
		set.setMargin(15, 15, 15, 15);
		fm.add(set);
		fm.add(new NullField());
		set = new ListStyleButtonSet();
		set.addCustom(null, _caret,"Others").setChangeListener(
				new PushScreenEventListener(new BillPayScreen(null,null,EditField.FILTER_NUMERIC)));
		
		set.setMargin(15, 15, 15, 15);
		fm.add(set);
		
		add(fm);
		
		
	}

	protected void clearFields() {
		// TODO Auto-generated method stub

	}

	public String getAction() {
		// TODO Auto-generated method stub
		return null;
	}

	public String getActivityTitle() {
		// TODO Auto-generated method stub
		return null;
	}

	public String getSummary() {
		// TODO Auto-generated method stub
		return null;
	}

	public void handleResponse(Object responseData) {
		// TODO Auto-generated method stub

	}

}
