package org.readycash.ui.screens;

import javax.microedition.lcdui.TextBox;

import org.readycash.core.BackEndProcessorEventListener;
import org.readycash.core.Security;
import org.readycash.core.StoreManager;

import net.rim.device.api.ui.DrawStyle;
import net.rim.device.api.ui.Field;
import net.rim.device.api.ui.UiApplication;
import net.rim.device.api.ui.XYEdges;
import net.rim.device.api.ui.component.BasicEditField;
import net.rim.device.api.ui.component.ButtonField;
import net.rim.device.api.ui.component.LabelField;
import net.rim.device.api.ui.component.PasswordEditField;
import net.rim.device.api.ui.component.TextField;
import net.rim.device.api.ui.container.VerticalFieldManager;

import com.blackberry.toolkit.ui.ForegroundManager;
import com.blackberry.toolkit.ui.component.ListStyleButtonField;
import com.blackberry.toolkit.ui.container.CurvedSideFieldManager;
import com.blackberry.toolkit.ui.container.HorizontalListStyleButtonSet;
import com.blackberry.toolkit.ui.container.VerticalButtonFieldSet;

public class ForgotSecretCodeScreen extends AppScreen {

	

	public ForgotSecretCodeScreen() {
		super();
		setTitle("Forgot Secret Code");
		// TODO Auto-generated constructor stub
		setupAccountNumber(cv);
		

		setupPIN(cv);
		fm.add(cv);
		
		setupActionButton(fm, "Retrieve Secret Code", "", this,false);
		add(fm);

	}

	public String getSummary() {
		return "Would you like to retrieve your Secret Code?";
	}

	public String getActivityTitle() {
		return "secret code";
	}

	public void handleResponse(Object responseData) {
		clearFields();
		UiApplication.getUiApplication().popScreen(this);
		// TODO Auto-generated method stub
		
	}
	
	
	protected void clearFields() {
		// TODO Auto-generated method stub
		super.pPIN.setText("");
		
	}
	
	public boolean onClose() {
		// TODO Auto-generated method stub
		clearFields();
		setDirty(false);
		return super.onClose();
	}

	public String getAction() {
		String encPIN = Security.encrypt(Security.KEY_USER, pPIN.getText());	
		String data = StoreManager.getPhoneNumber()+"/"+encPIN;
		data = Security.encrypt(Security.KEY_USER,data);
		return "X/FC/"  + data;
	}

	
}
