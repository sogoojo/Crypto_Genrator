package org.readycash.ui.screens;

import javax.microedition.global.Formatter;

import org.readycash.core.Security;
import org.readycash.core.StoreManager;

import net.rim.device.api.ui.UiApplication;
import net.rim.device.api.ui.component.BasicEditField;
import net.rim.device.api.ui.component.LabelField;
import com.blackberry.toolkit.ui.component.BorderedEditField;

public class SendMoneyScreen extends AppScreen {

	BorderedEditField brPhoneNumber;

	String recipient = null;
	
	 

	public SendMoneyScreen(String recipeint) {
		// TODO Auto-generated constructor stub
		super();
		setTitle("Send Money");
		this.recipient = recipeint;

		cv.add(new LabelField("Recipients Phone #: "));
		brPhoneNumber = new BorderedEditField(BasicEditField.FILTER_PHONE);
		if (recipeint != null) {
			brPhoneNumber.setText(recipeint);
		}
		
		cv.add(brPhoneNumber);

		setupAmount(cv);

		setupPIN(cv);

		fm.add(cv);

		setupActionButton(fm, "Send Money", "", this);
		add(fm);
	}

	public String getActivityTitle() {
		// TODO Auto-generated method stub
		return "send money ";
	}

	public String getSummary() {
		StringBuffer sb = new StringBuffer();
		sb.append("You are about to send \n");
		double amt = Double.parseDouble(bAmount.getText());
		sb.append("NGN " + amt);
		sb.append(" to " + brPhoneNumber.getText());
		return sb.toString();
	}

	public void handleResponse(Object responseData) {
		clearFields();
		UiApplication.getUiApplication().popScreen(this);
	}

	protected void clearFields() {
		bAmount.setText("");
		brPhoneNumber.setText("");
		pPIN.setText("");
	}

	public boolean onClose() {
		// TODO Auto-generated method stub
		clearFields();
		setDirty(false);
		return super.onClose();
	}
	

	public String getAction() {
		// TODO Auto-generated method stub
		String encPIN = Security.encrypt(Security.KEY_USER, pPIN.getText());	
		recipient = recipient == null ? brPhoneNumber.getText() : recipient; 
		String data = StoreManager.getPhoneNumber()+"/"+encPIN + "/" + recipient + "/" +bAmount.getText();
		data = Security.encrypt(Security.KEY_USER,data);
		return "X/SM/"  + data;
	}

	
}
