package org.readycash.ui.screens;

import org.readycash.core.Security;
import org.readycash.core.StoreManager;
import net.rim.device.api.ui.UiApplication;


public class BalanceScreen extends AppScreen {

	

	public BalanceScreen() {
		super();
		setTitle("Balance");
		// TODO Auto-generated constructor stub
		setupAccountNumber(cv);
		

		setupPIN(cv);
		fm.add(cv);
		
		setupActionButton(fm, "Get Balance", "", this,true);
		add(fm);

	}

	public String getSummary() {
		return "Would you like to retrieve your balance?";
	}

	public String getActivityTitle() {
		return "balance";
	}

	public void handleResponse(Object responseData) {
		clearFields();
		UiApplication.getUiApplication().popScreen(this);
		// TODO Auto-generated method stub
		
	}
	
	
	protected void clearFields() {
		// TODO Auto-generated method stub
		super.pPIN.setText("");
		
	}
	
	public boolean onClose() {
		// TODO Auto-generated method stub
		clearFields();
		setDirty(false);
		return super.onClose();
	}

	public String getAction() {
		String encPIN = Security.encrypt(Security.KEY_USER, pPIN.getText());	
		String data = StoreManager.getPhoneNumber()+"/"+encPIN;
		data = Security.encrypt(Security.KEY_USER,data);
		return "X/BE/"  + data;
	}

	
}
