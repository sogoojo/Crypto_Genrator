package org.readycash.ui.screens;

import org.readycash.core.FieldValidator;
import org.readycash.core.Security;
import org.readycash.core.StoreManager;

import net.rim.device.api.ui.UiApplication;
import net.rim.device.api.ui.component.LabelField;

import com.blackberry.toolkit.ui.component.BorderedEditField;

public class ClaimMoneyScreen extends AppScreen {

	BorderedEditField bTxCode = null;

	public ClaimMoneyScreen() {
		super();
		setTitle("Claim Money");
		setupAccountNumber(cv);
		bTxCode = new BorderedEditField();
		cv.add(new LabelField("Transaction Code "));
		cv.add(bTxCode);
		setupAmount(cv);
		setupPIN(cv);
		fm.add(cv);
		setupActionButton(fm, "Claim Money", getAction(), this,false);
		add(fm);
		

	}

	protected void clearFields() {
		super.pPIN.setText("");
		super.bAmount.setText("");
		this.bTxCode.setText("");

	}
	
	public boolean onClose() {
		// TODO Auto-generated method stub
		clearFields();
		setDirty(false);
		return super.onClose();
	}

	public String getAction() {
		// TODO Auto-generated method stub
		String encPIN = Security.encrypt(Security.KEY_USER, pPIN.getText());	
		String data = StoreManager.getPhoneNumber()+"/"+encPIN + "/"+ bTxCode.getText() + "/" +bAmount.getText();
		data = Security.encrypt(Security.KEY_USER,data);
		return "X/CF/"  + data;
	}

	public String getActivityTitle() {
		// TODO Auto-generated method stub
		return "Claim money";
	}

	public String getSummary() {
		// TODO Auto-generated method stub
		return "Would you like to claim the funds tied to the transaction code?";
	}
	
	public boolean isDataValid() {
		fv.checkLenght("Transaction Code", bTxCode, 10,
				FieldValidator.GREATER_THAN);
		return super.isDataValid();
	}

	public void handleResponse(Object responseData) {
		clearFields();
		UiApplication.getUiApplication().popScreen(this);

	}

}
