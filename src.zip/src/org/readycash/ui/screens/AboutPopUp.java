package org.readycash.ui.screens;

import net.rim.device.api.ui.Manager;
import net.rim.device.api.ui.container.PopupScreen;


public class AboutPopUp extends PopupScreen {

	public AboutPopUp(Manager arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	

}
