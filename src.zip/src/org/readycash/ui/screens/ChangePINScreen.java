package org.readycash.ui.screens;

import org.readycash.core.FieldValidator;
import org.readycash.core.Security;
import org.readycash.core.StoreManager;

import net.rim.device.api.ui.UiApplication;

import com.blackberry.toolkit.ui.component.BorderedPasswordField;

public class ChangePINScreen extends AppScreen {

	public BorderedPasswordField bpNewPIN;
	public BorderedPasswordField bpReNewPIN;

	public ChangePINScreen() {
		super();
		setTitle("Change PIN");
		setupAccountNumber(cv);
		setupPIN(cv);
		bpNewPIN = new BorderedPasswordField();
		bpReNewPIN = new BorderedPasswordField();
		setupPIN(cv, "New PIN", bpNewPIN);
		setupPIN(cv, "Re-Enter New PIN", bpReNewPIN);

		fm.add(cv);
		setupActionButton(fm, "Change PIN", "", this);
		add(fm);

	}
	public boolean isDataValid() {
		fv.checkLenght("New PIN", bpNewPIN, 4, FieldValidator.EXACT);
		fv.compareValues("PIN ",pPIN,"New PIN ",bpNewPIN, FieldValidator.GREATER_THAN);
		fv.compareValues("New PIN ",bpNewPIN,"Re-Enter New PIN ",bpReNewPIN, FieldValidator.EXACT);		
		return super.isDataValid();
	}
	

	public String getActivityTitle() {
		// TODO Auto-generated method stub
		return "change PIN";
	}

	public String getSummary() {
		// TODO Auto-generated method stub
		return "Change your PIN";
	}

	public void handleResponse(Object responseData) {
		// TODO Auto-generated method stub

		clearFields();
		UiApplication.getUiApplication().popScreen(this);
	}

	protected void clearFields() {
		bpNewPIN.setText("");
		bpReNewPIN.setText("");
		pPIN.setText("");
	}

	public boolean onClose() {
		// TODO Auto-generated method stub
		clearFields();
		setDirty(false);
		return super.onClose();
	}

	public String getAction() {
		String encPIN = Security.encrypt(Security.KEY_USER, pPIN.getText());
		String newPIN = Security.encrypt(Security.KEY_USER, bpNewPIN.getText());
		String data = StoreManager.getPhoneNumber() + "/" + encPIN + "/"
				+ newPIN;
		data = Security.encrypt(Security.KEY_USER, data);
		return "X/CP/" + data;
	}

}
