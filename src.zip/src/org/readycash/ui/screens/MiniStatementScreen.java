package org.readycash.ui.screens;

import org.readycash.core.Security;
import org.readycash.core.StoreManager;

import net.rim.device.api.ui.UiApplication;

public class MiniStatementScreen extends AppScreen {

	public MiniStatementScreen() {
		super();
		setTitle("Last 5 Transactions");
		setupAccountNumber(cv);
		setupPIN(cv);
		fm.add(cv);
		setupActionButton(fm, "Last 5 Transactions", "", this);
		add(fm);

	}

	protected void clearFields() {

		super.pPIN.setText("");
	}

	public String getAction() {
		String encPIN = Security.encrypt(Security.KEY_USER, pPIN.getText());
		String data = StoreManager.getPhoneNumber() + "/" + encPIN;
		data = Security.encrypt(Security.KEY_USER, data);
		return "X/MS/" + data;
	}

	public String getActivityTitle() {
		// TODO Auto-generated method stub
		return "last 5 transactions";
	}

	

	public String getSummary() {
		// TODO Auto-generated method stub
		return "Would you like to retrieve your last 5 transactions?";
	}

	public void handleResponse(Object responseData) {
		// TODO Auto-generated method stub
		UiApplication.getUiApplication().popScreen(this);

	}

	public boolean onClose() {
		clearFields();
		setDirty(false);
		return super.onClose();
	}

}
