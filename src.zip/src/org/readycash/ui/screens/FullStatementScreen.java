package org.readycash.ui.screens;

import java.util.Date;

import net.rim.device.api.i18n.DateFormat;
import net.rim.device.api.i18n.SimpleDateFormat;
import net.rim.device.api.ui.UiApplication;
import net.rim.device.api.ui.component.DateField;
import net.rim.device.api.ui.component.EditField;
import net.rim.device.api.ui.component.LabelField;
import net.rim.device.api.ui.container.VerticalFieldManager;
import net.rim.device.api.ui.text.TextFilter;
import com.blackberry.toolkit.ui.container.JustifiedEvenlySpacedHorizontalFieldManager;

import org.readycash.core.FieldValidator;
import org.readycash.core.Security;
import org.readycash.core.StoreManager;
import org.readycash.ui.component.InfoLabel;

import com.blackberry.toolkit.ui.component.BorderedEditField;

public class FullStatementScreen extends AppScreen {

	BorderedEditField bEmail;
	DateField dfrom;
	DateField dto;

	public FullStatementScreen() {
		super();
		setTitle("Statement for a period");
		setupAccountNumber(cv);
		VerticalFieldManager j = new VerticalFieldManager();
		Date d = new Date();
		dfrom = new DateField("From : ", d.getTime(), new SimpleDateFormat(
				DateFormat.DATE_MEDIUM));
		dto = new DateField("To : ", d.getTime(), new SimpleDateFormat(
				DateFormat.DATE_MEDIUM));

		j.add(dfrom);
		j.add(dto);
		cv.add(j);
		cv.add(new InfoLabel(0, "statement would be sent via email to", 0));
		cv.add(new LabelField("E-Mail Address: "));
		bEmail = new BorderedEditField(EditField.FILTER_EMAIL);

		cv.add(bEmail);
		setupPIN(cv);
		fm.add(cv);
		setupActionButton(fm, "Request Statement", "", this);
		add(fm);

	}

	public boolean isDataValid() {
		fv.compareValues("to", dto, "from", dfrom, FieldValidator.GREATER_THAN);
		fv.checkValidEmail("E-Mail", bEmail);
		return super.isDataValid();
	}
	
	public FullStatementScreen(long style) {
		super(style);
		// TODO Auto-generated constructor stub
	}

	public boolean onClose() {
		// TODO Auto-generated method stub
		clearFields();
		setDirty(false);
		return super.onClose();
	}
	protected void clearFields() {
		bEmail.setText("");
		pPIN.setText("");

	}

	public String getAction() {
		String encPIN = Security.encrypt(Security.KEY_USER, pPIN.getText());	
		String data = StoreManager.getPhoneNumber()+"/"+encPIN + "/" + dfrom.getDate() + "/" + dto.getDate() + "/"+ bEmail.getText();
		data = Security.encrypt(Security.KEY_USER,data);
		return "X/FS/"  + data;
	}

	public String getActivityTitle() {
		// TODO Auto-generated method stub
		return "statement for a period";
	}

	

	public String getSummary() {
		String from = DateFormat.getInstance(DateFormat.DATE_SHORT)
				.formatLocal(dfrom.getDate());
		String to = DateFormat.getInstance(DateFormat.DATE_SHORT).formatLocal(
				dto.getDate());

		return "Would you like to get your statement from " + from + "to " + to
				+ " ?";
	}

	public void handleResponse(Object responseData) {
		// TODO Auto-generated method stub

		UiApplication.getUiApplication().popScreen(this);

	}

}
