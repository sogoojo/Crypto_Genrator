package org.readycash.ui.screens;

import net.rim.device.api.ui.Font;
import net.rim.device.api.ui.Ui;
import net.rim.device.api.ui.UiApplication;
import net.rim.device.api.ui.component.LabelField;
import net.rim.device.api.ui.component.SeparatorField;

public class OTPScreen extends AppScreen {

	public OTPScreen() {
		super();
		setTitle("Generate OTP");
		LabelField lf = new LabelField("One Time Passwords (OTP) are used " +
				" to authorize transactions" +
				" outside the readycash" +
				" appication this includes ATM withdrawals" +
				" and Online purchases" );
		Font f = Font.getDefault().derive(Font.PLAIN, 5, Ui.UNITS_pt);
		lf.setFont(f);
		cv.add(lf);
		cv.add(new SeparatorField());
		setupPIN(cv);
		fm.add(cv);
		setupActionButton(fm, "Generate OTP", null, this);
		add(fm);
	}

	
	public String getActivityTitle() {
		// TODO Auto-generated method stub
		return null;
	}

	public String getSummary() {
		// TODO Auto-generated method stub
		return null;
	}


	public void handleResponse(Object responseData) {
		clearFields();
		UiApplication.getUiApplication().popScreen(this);
		
	}
	
	public void clearFields()
	{
		pPIN.setText(null);
	}
	
	public boolean onClose() {
		// TODO Auto-generated method stub
		clearFields();
		setDirty(false);
		return super.onClose();
	}


	public String getAction() {
		// TODO Auto-generated method stub
		return null;
	}


	public String getInvalidDataSummary() {
		// TODO Auto-generated method stub
		return null;
	}

}
