package org.readycash.ui.screens;

import javax.microedition.global.Formatter;

import org.readycash.core.Security;
import org.readycash.core.StoreManager;

import com.blackberry.toolkit.ui.component.BorderedEditField;

import net.rim.device.api.ui.UiApplication;
import net.rim.device.api.ui.component.LabelField;
import net.rim.device.api.ui.component.ObjectChoiceField;

public class WithdrawBankScreen extends AppScreen {

	private ObjectChoiceField ocfBanks;
	private String[] banks = { "Access Bank", "Afribank", "Bank PHB",
			"Diamond Bank", "Ecobank", "ETB", "Fidelity Bank", "FinBank",
			"FCMB", "GTB", "Intercontinetal Bank", "Oceanic Bank", "Skye Bank",
			"Spring Bank", "Stanbic IBTC", "Standard Chatered",
			"Sterling Bank", "UBA", "Union Bank", "Unity Bank", "WEMA Bank",
			"Zenith Bank" };

	public WithdrawBankScreen() {
		// TODO Auto-generated constructor stub
		// TODO Auto-generated constructor stub

		super();
		setTitle("Withdraw Funds From Bank");
		setupAccountNumber(cv);
		cv.add(new LabelField("Bank : "));
		ocfBanks = new ObjectChoiceField("", banks);
		cv.add(ocfBanks);

		setupAmount(cv);
		setupPIN(cv);

		fm.add(cv);
		setupActionButton(fm, "Withdraw", "", this);

		add(fm);
	}

	public final String getActivityTitle() {
		return "withdraw funds";
	}

	public final String getSummary() {

		StringBuffer sb = new StringBuffer();
		sb.append("You are about to withdraw \r\n");
		double amt = Double.parseDouble(bAmount.getText());
		sb.append("NGN " + amt + "\n");
		sb.append("From " + banks[ocfBanks.getSelectedIndex()]);
		return sb.toString();
	}

	public void handleResponse(Object responseData) {
		// TODO Auto-generated method stub

		clearFields();
		UiApplication.getUiApplication().popScreen(this);

	}

	protected void clearFields() {
		// bBankId.setText("");
		bAmount.setText("");
		pPIN.setText("");

	}

	public boolean onClose() {
		// TODO Auto-generated method stub
		clearFields();
		setDirty(false);
		return super.onClose();
	}

	public String getAction() {
		String encPIN = Security.encrypt(Security.KEY_USER, pPIN.getText());
		String bank = banks[ocfBanks.getSelectedIndex()];
		String data = StoreManager.getPhoneNumber() + "/" + encPIN + "/" + bank
				+ "/" + bAmount.getText();
		data = Security.encrypt(Security.KEY_USER, data);
		return "X/BW/" + data;
	}

}
