/**
 * 
 */
package org.readycash.ui.screens;

import net.rim.device.api.ui.UiApplication;
import net.rim.device.api.ui.component.BasicEditField;
import net.rim.device.api.ui.component.LabelField;

import org.readycash.core.FieldValidator;
import org.readycash.core.Security;
import org.readycash.core.StoreManager;
import org.readycash.ui.component.InfoLabel;

import com.blackberry.toolkit.ui.component.BorderedEditField;
import com.blackberry.toolkit.ui.component.BorderedPasswordField;

/**
 * @author Emeka
 * 
 */
public class VerificationScreen extends AppScreen {

	BorderedPasswordField bpReenter;
	BorderedEditField bVerify;
	BorderedEditField bSecret;

	/**
	 * 
	 */

	public VerificationScreen() {
		super();
		setTitle("Verification");
		cv
				.add(new InfoLabel(
						0,
						"Enter the verification code sent to you after registering",
						0));

		cv.add(new LabelField("Verification Code"));
		bVerify = new BorderedEditField(BasicEditField.FILTER_NUMERIC);
		cv.add(bVerify);
		setupPIN(cv);
		setupPIN(cv, "Re-Enter PIN", bpReenter);
		cv.add(new InfoLabel(0,
				"Enter a secret code, this would be used for customer support",
				0));
		cv.add(new LabelField("Secret Code"));
		bSecret = new BorderedEditField();
		cv.add(bSecret);
		fm.add(cv);

		setupActionButton(fm, "Verify", "", this);
		add(fm);
	}

	/**
	 * @param style
	 */
	public VerificationScreen(long style) {
		super(style);
		// TODO Auto-generated constructor stub
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.readycash.ui.screens.AppScreen#getActivityTitle()
	 */
	public String getActivityTitle() {
		// TODO Auto-generated method stub
		return "verfication";
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.readycash.ui.screens.AppScreen#getSummary()
	 */
	public String getSummary() {
		// TODO Auto-generated method stub
		return "You are about to verify";
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.readycash.ui.screens.AppScreen#handleResponse(java.lang.Object)
	 */
	public void handleResponse(Object responseData) {
		String resp = (String) responseData;
		// if(resp == "301"){
		StoreManager.setVerifiedStatus(Boolean.TRUE);
		UiApplication.getUiApplication().popScreen(this);
		UiApplication.getUiApplication().pushScreen(new MainMenuScreen());

	}

	protected void clearFields() {
		// TODO Auto-generated method stub

	}

	public boolean isDataValid() {
		fv.checkLenght("Verification Code", bVerify, 10,
				FieldValidator.GREATER_THAN);
		if (super.isDataValid()) {
			String dek = StoreManager.getDEK();
			String verifier = dek.substring(0, 13) + "0";
			long rhs = Long.parseLong(verifier);
			long lhs = Long.parseLong(bVerify.getText());
			long res = rhs ^ lhs;
			String s_res = String.valueOf(res);
			boolean valid = s_res.startsWith("234")
					&& Security.luhnCheck(s_res);
			if (valid) {
				StoreManager.setPhoneNumber(s_res.substring(0,
						s_res.length() - 1));
				return true;
			}
		}
		return true;

	}

	public String getInvalidDataSummary() {
		// TODO Auto-generated method stub
		if (super.isDataValid()) {
			return "Your verification failed, check to make sure you eneterd the proper verification code "
					+ "and you are using the same phone number you registered with";
		} else
			return super.getInvalidDataSummary();
	}

	public String getAction() {
		String encPIN = Security.encrypt(Security.KEY_USER, pPIN.getText());
		String encCode = Security.encrypt(Security.KEY_USER, bSecret.getText());
		String data = StoreManager.getPhoneNumber() + "/" + encPIN + "/"
				+ encCode;
		data = Security.encrypt(Security.KEY_USER, data);
		return "X/VU/" + data;
	}

	public boolean onClose() {
		if (askQuit()) {
			setDirty(false);
			return super.onClose();
		}
		return false;
	}

}
