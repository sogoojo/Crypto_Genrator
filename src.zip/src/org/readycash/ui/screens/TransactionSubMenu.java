package org.readycash.ui.screens;

import org.readycash.core.PushScreenEventListener;
import com.blackberry.toolkit.ui.container.ListStyleButtonSet;

public class TransactionSubMenu extends AppScreen {

	public TransactionSubMenu() {
		// TODO Auto-generated constructor stub
		super();
		setTitle("Transactions");
		ListStyleButtonSet buttonSet = new ListStyleButtonSet();
		buttonSet.addCustom(null, _caret, "Send Money").setChangeListener(
				new PushScreenEventListener(new SendMoneyScreen(null)));
		buttonSet.addCustom(null, _caret, "Withdraw Money").setChangeListener(
				new PushScreenEventListener(new WithdrawSubMenu()));
		buttonSet.addCustom(null, _caret, "Claim Money").setChangeListener(
				new PushScreenEventListener(new ClaimMoneyScreen()));
		fm.add(buttonSet);
		add(fm);

	}

	protected void clearFields() {
		// TODO Auto-generated method stub

	}

	public String getActivityTitle() {
		// TODO Auto-generated method stub
		return null;
	}

	public String getSummary() {
		// TODO Auto-generated method stub
		return null;
	}

	public void handleResponse(Object responseData) {
		// TODO Auto-generated method stub

	}

	public String getAction() {
		// TODO Auto-generated method stub
		return null;
	}

	public String getInvalidDataSummary() {
		// TODO Auto-generated method stub
		return null;
	}

}
