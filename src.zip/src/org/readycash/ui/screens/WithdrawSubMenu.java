package org.readycash.ui.screens;

import org.readycash.core.PushScreenEventListener;

import com.blackberry.toolkit.ui.container.ListStyleButtonSet;

public class WithdrawSubMenu extends AppScreen {

	public WithdrawSubMenu() {
		super();
		setTitle("Withdraw Menu");
		
		
		ListStyleButtonSet buttonSet = new ListStyleButtonSet();
		buttonSet.addCustom(null, _caret, "From Agent").setChangeListener(new PushScreenEventListener(new WithdrawScreen()));//, new MainMenuScreen());
		buttonSet.addCustom(null, _caret, "From Bank").setChangeListener(new PushScreenEventListener(new WithdrawBankScreen()));
		
		
		fm.add(buttonSet);
		add(fm);
	}
	public String getActivityTitle() {
		// TODO Auto-generated method stub
		return null;
	}

	public String getSummary() {
		// TODO Auto-generated method stub
		return null;
	}

	public void handleResponse(Object responseData) {
		// TODO Auto-generated method stub

	}
	protected void clearFields() {
		// TODO Auto-generated method stub
		
	}
	public String getAction() {
		// TODO Auto-generated method stub
		return null;
	}
	public String getInvalidDataSummary() {
		// TODO Auto-generated method stub
		return null;
	}

}
