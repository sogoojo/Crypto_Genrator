package org.readycash.ui.screens;

import javax.microedition.global.Formatter;

import org.readycash.core.Security;
import org.readycash.core.StoreManager;

import net.rim.device.api.ui.UiApplication;
import net.rim.device.api.ui.component.LabelField;
import net.rim.device.api.ui.component.ObjectChoiceField;

public class RechargeScreen extends AppScreen {

	private ObjectChoiceField ocfNetworks;
	private String[] choices = { "Airtel", "Etisalat", "GLO", "MTN",
			"Multilinks/Telkom", "MTEL", "Starcomms", "Visafone", "Zoom" };

	public RechargeScreen() {
		super();
		setTitle("Recharge");
		setupAccountNumber(cv);
		setupPhoneNumber(cv);

		cv.add(new LabelField("Network: "));
		ocfNetworks = new ObjectChoiceField("", choices);

		cv.add(ocfNetworks);
		setupAmount(cv);
		setupPIN(cv);
		fm.add(cv);

		setupActionButton(fm, "Recharge Phone", "http://google.com", this);

		add(fm);
		// TODO Auto-generated constructor stub
	}

	public final String getActivityTitle() {
		return "recharge phone";
	}

	public final String getSummary() {
		StringBuffer sb = new StringBuffer();
		sb.append("You are about to purchase \r\n");
		sb.append("an " + choices[ocfNetworks.getSelectedIndex()]
				+ " voucher\r\n");

		double amt = Double.parseDouble(bAmount.getText());
		sb.append(" worth NGN " + new Formatter().formatNumber(amt) + "\r\n");
		sb.append("to be sent to " + bPhoneNumber.getText());
		return sb.toString();
	}

	public void handleResponse(Object responseData) {
		// TODO Auto-generated method stub
		clearFields();
		UiApplication.getUiApplication().popScreen(this);
	}
	
	public void clearFields()
	{
		bPhoneNumber.setText("");
		pPIN.setText("");
		ocfNetworks.setSelectedIndex(0);
	}
	
	public boolean onClose() {
		clearFields();
		setDirty(false);
		return super.onClose();
	}

	public String getAction() {
		
		String encPIN = Security.encrypt(Security.KEY_USER, pPIN.getText());
		String voucher = Security.encrypt(Security.KEY_USER, choices[ocfNetworks.getSelectedIndex()]);
		String data = StoreManager.getPhoneNumber()+"/"+encPIN+ "/" +voucher + "/" +bPhoneNumber.getText() + "/" +bAmount.getText();
		data = Security.encrypt(Security.KEY_USER,data);
		return "X/RP/"  + data;
	}


}
