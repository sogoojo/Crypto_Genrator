package org.readycash.core;

import java.io.IOException;
import java.util.Vector;

import javax.microedition.io.Connector;
import javax.wireless.messaging.BinaryMessage;
import javax.wireless.messaging.Message;
import javax.wireless.messaging.MessageConnection;
import javax.wireless.messaging.MessageListener;
import javax.wireless.messaging.TextMessage;

import org.readycash.ui.ReadyCashSystemMenu;
import org.readycash.ui.screens.AppScreen;
import org.readycash.ui.screens.MainMenuScreen;
import org.readycash.ui.screens.RegisterScreen;
import org.readycash.ui.screens.VerificationScreen;

import net.rim.blackberry.api.menuitem.ApplicationMenuItemRepository;
import net.rim.device.api.system.PersistentObject;
import net.rim.device.api.system.PersistentStore;
import net.rim.device.api.ui.UiApplication;
import net.rim.device.api.ui.component.Dialog;

public class App extends UiApplication {

	/**
	 * @param args
	 */
	MessageConnection _mc = null;

	public App() {

		new StoreManager();
		if (!StoreManager.isDEKSet()) {

			StoreManager.setDEK();
		}
		if (StoreManager.getRegisteredStatus().booleanValue()) {
			if (StoreManager.getVerifiedStatus().booleanValue()) {
				pushScreen(new MainMenuScreen());
			} else {
				pushScreen(new VerificationScreen());
			}
		} else
			pushScreen(new RegisterScreen());

	}

	// Additional code required for complete sample.

	public static void main(String[] args) {

		if (args != null && args.length > 0 && args[0].equals("autostartup")) {
			// Keep this instance around for rendering
			// Notification dialogs.
			ReadyCashSystemMenu menuitem = new ReadyCashSystemMenu();
			ApplicationMenuItemRepository
					.getInstance()
					.addMenuItem(
							ApplicationMenuItemRepository.MENUITEM_ADDRESSCARD_VIEW
									| ApplicationMenuItemRepository.MENUITEM_ADDRESSCARD_VIEW,
							menuitem);
			// new SMSNotifier().enterEventDispatcher();
		}

		/*
		 * else if (args != null && args.length > 0 && args[0].equals("sms")) {
		 * new SMSNotifier().enterEventDispatcher(); } else { new
		 * App().enterEventDispatcher(); }
		 */new App().enterEventDispatcher();
	}
}
