package org.readycash.core;

import java.io.DataInputStream;
import java.io.IOException;

import javax.microedition.io.Connector;
import javax.microedition.io.Datagram;
import javax.microedition.io.DatagramConnection;
import javax.microedition.io.HttpConnection;
import javax.wireless.messaging.MessageConnection;
import javax.wireless.messaging.TextMessage;

import org.readycash.ui.screens.AppScreen;

import net.rim.device.api.servicebook.ServiceBook;
import net.rim.device.api.servicebook.ServiceRecord;
import net.rim.device.api.ui.UiApplication;
import net.rim.device.api.ui.component.Dialog;

public class BackEndProcessor implements Runnable {

	String url = null;
	String msg = null;
	AppScreen owner = null;
	boolean failOver = false;

	public BackEndProcessor(String url, String msg, AppScreen owner,
			boolean failOver) {
		// TODO Auto-generated constructor stub
		this.url = url;
		this.msg = msg;
		this.owner = owner;
		this.failOver = failOver;

	}

	private String readResponse(DataInputStream is) throws IOException {
		StringBuffer sb = new StringBuffer();

		int chr;
		while ((chr = is.read()) != -1)
			sb.append((char) chr);
		return sb.toString();
	}

	private String smsSend() throws IOException {

		/*
		 * DatagramConnection dgConn; dgConn =
		 * (DatagramConnection)Connector.open("sms://08076666600"); byte[] data
		 * = ("RC "+url).getBytes("ASCII"); Datagram dg =
		 * dgConn.newDatagram(dgConn.getMaximumLength()); dg.setData(data, 0,
		 * data.length); dgConn.send(dg);
		 */
		MessageConnection conn = (MessageConnection) Connector
				.open("sms://30012");
		// (MessageConnection)Connector.open("sms://08076666600");
		TextMessage msgOut = (TextMessage) conn
				.newMessage(MessageConnection.TEXT_MESSAGE);
		msgOut.setPayloadText("RC " + url);
		conn.send(msgOut);
		return msg
				+ " was sucessfully sent, check your SMS Inbox for the response";
		/*
		 * try { Thread.sleep(8000); } catch (Exception e) { }
		 */
	}

	private String wapSend() throws Exception {
		ServiceBook sb = ServiceBook.getSB();
		ServiceRecord[] records = sb.findRecordsByCid("WPTCP");
		String uid = null;
		String responseMessage = "";
		HttpConnection httpConn = null;
		int responseCode = -1;
		DataInputStream is = null;

		for (int i = 0; i < records.length; i++) {
			if (records[i].isValid() && !records[i].isDisabled()) {

				if (records[i].getUid() != null
						&& records[i].getUid().length() != 0) {
					if ((records[i].getUid().toLowerCase().indexOf("wifi") == -1)
							&& (records[i].getUid().toLowerCase()
									.indexOf("mms") == -1)) {
						uid = records[i].getUid();
						break;
					}
				}
			}
		}
		if (uid != null) {
			try {
				String surl ="http://62.173.32.27:8080/rest"
								+ "url.substring(1)"+"\\;ConnectionUID=\\" + uid;
				Dialog.inform(surl);
				httpConn = (HttpConnection) Connector
						.open(surl);
				responseCode = httpConn.getResponseCode();
				if (responseCode == httpConn.HTTP_OK) {
					is = httpConn.openDataInputStream();
					responseMessage = readResponse(is);
					return responseMessage;
					// open a WAP 2 connection

				} else {
					// Consider another transport or alternative action.
					throw new Exception("failed gprs");
				}
			} finally {
				try {
					if (is != null) {
						is.close();
					}
					if (httpConn != null) {
						httpConn.close();
					}

				} catch (Exception e) {
				}
				httpConn = null;
			}
		}
		return null;
	}

	private String httpSend() throws Exception {
		String responseMessage = "";
		HttpConnection httpConn = null;
		int responseCode = -1;
		DataInputStream is = null;
		responseMessage = "Your request failed!";
		try {
			// force ";deviceside=true" to make easy to try in Simulator
			httpConn = (HttpConnection) Connector
					.open(url + ";deviceside=true");
			responseCode = httpConn.getResponseCode();
			if (responseCode == httpConn.HTTP_OK) {
				is = httpConn.openDataInputStream();
				responseMessage = readResponse(is);
			}
		} catch (IOException ioe) {
			throw ioe;
			// responseMessage = "IOException: " + url + " : " + ioe.toString();
		} catch (Exception e) {
			// responseMessage = "Exception: " + url + " : " + e.toString();
			throw e;
		} finally {
			try {
				if (is != null) {
					is.close();
				}
				if (httpConn != null) {
					httpConn.close();
				}

			} catch (Exception e) {
			}
			httpConn = null;
		}
		// System.out.println(responseMessage);
		// On the Simulator, this is typically too fast, so we slow it down a
		// bit

		try {
			Thread.sleep(8000);
		} catch (Exception e) {
		}
		return responseMessage;

	}

	public void run() {

		String responseMessage = null;
		boolean sent = false;
		try {
			if (failOver) {
				try {
					responseMessage = wapSend();
					responseMessage = httpSend();

					sent = true;
				} catch (Exception ex) {
					try {
						responseMessage = smsSend();
						sent = true;
					} catch (Exception e) {
						sent = false;
					}
				}
			} else {
				responseMessage = smsSend();
				sent = true;
			}

		} catch (IOException io) {
			sent = false;
		}

		final String textString = responseMessage;
		final String prev = msg;
		final boolean fsent = sent;
		UiApplication.getUiApplication().invokeLater(new Runnable() {
			public void run() {
				if (fsent) {
					Dialog.inform(textString);
					owner.handleResponse(textString);
				} else {
					Dialog.inform(prev + "failed, Pls try again later");
				}

			}
		});

	}
}
