package org.readycash.core;

import net.rim.device.api.system.Application;

public class BackgroundApp extends Application {
	
}
