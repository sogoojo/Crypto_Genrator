package org.readycash.core;

import java.util.Vector;

import net.rim.device.api.util.Persistable;

 public class SettingsInfo implements Persistable {

	 private Vector _elements;
	 private static final int REGISTER_STATUS = 0;
	 private static final int PHONE_NUMBER = 1;
	 private static final int VERIFIED_STATUS = 2;
	 private static final int DEK = 3;
	 
	 
	 public SettingsInfo (){
		 _elements = new Vector();
		 for(int i = 0 ; i < 4 ; i ++){
			 _elements.addElement(new Object());
		 }
		 _elements.setElementAt(Boolean.FALSE,REGISTER_STATUS);
		 _elements.setElementAt( Boolean.FALSE,VERIFIED_STATUS);
		 _elements.setElementAt("", PHONE_NUMBER);
		 _elements.setElementAt("", DEK);
		 
	 }
	 
	 public Boolean isRegistered()
	 {
		return (Boolean) _elements.elementAt(REGISTER_STATUS);
	 }
	 
	 public void setRegistered(Boolean registered)
	 {
		 _elements.setElementAt( registered,REGISTER_STATUS);
	 }
	 
	 public String getPhoneNumber()
	 {
		 return (String) _elements.elementAt(PHONE_NUMBER);
	 }
	 
	 public void setPhoneNumber(String phonenumber)
	 {
		 _elements.setElementAt(phonenumber, PHONE_NUMBER);
	 }
	 
	 public Boolean isVerified()
	 {
		 return (Boolean) _elements.elementAt(VERIFIED_STATUS);
	 }
	 
	 public void setVerified(Boolean verified)
	 {
		 _elements.setElementAt( verified,VERIFIED_STATUS);
	 }
	 
	 public void setEncryptionKey(String encKey)
	 {
		 _elements.setElementAt(encKey, DEK);
	 }
	 
	 public String getEncyptionKey()
	 {
		 return (String)_elements.elementAt(DEK);
	 }
	 
}
