package org.readycash.core;

import net.rim.device.api.crypto.RandomSource;
import net.rim.device.api.system.PersistentObject;
import net.rim.device.api.system.PersistentStore;

public class StoreManager {
	
	public static SettingsInfo _settingsdata;/* org.readycash.core.StoreManager.SettingsInfo 0xbef6af99bf90169fL  */
	
	public static PersistentObject settingsstore;

	static {
		//
		settingsstore = PersistentStore
				.getPersistentObject(0xbef6af99bf90169fL);
		synchronized (settingsstore) {
			if (settingsstore.getContents() == null) {
				settingsstore.setContents(new SettingsInfo());
				settingsstore.commit();
			}
		}
	//	_settingsdata = new SettingsInfo();
		_settingsdata = (SettingsInfo) settingsstore.getContents();
	}
	
	public static Boolean getRegisteredStatus()
	{
		synchronized (settingsstore) {
			_settingsdata = (SettingsInfo )settingsstore.getContents();
			if(!(_settingsdata == null))
			{
				SettingsInfo s = (SettingsInfo)_settingsdata;
				return s.isRegistered();
			}
			return Boolean.FALSE;
		}
	}
	
	public static Boolean getVerifiedStatus()
	{
		synchronized (settingsstore) {
			_settingsdata = (SettingsInfo )settingsstore.getContents();
			if(!(_settingsdata == null))
			{
				SettingsInfo s = (SettingsInfo)_settingsdata;
				return s.isVerified();
			}
			return Boolean.FALSE;
		}
	}
	
	public static void setRegisteredStatus(Boolean b)
	{
		SettingsInfo info = _settingsdata;
		info.setRegistered(b);
		_settingsdata = info;
		synchronized (settingsstore) {
			settingsstore.setContents(_settingsdata);
			settingsstore.commit();
		}
	}
	
	public static void setVerifiedStatus(Boolean b)
	{
		SettingsInfo info = _settingsdata;
		info.setVerified(b);
		_settingsdata = info;
		synchronized (settingsstore) {
			settingsstore.setContents(_settingsdata);
			settingsstore.commit();
		}
	}
	
	public static boolean isDEKSet()
	{
		return !getDEK().equalsIgnoreCase("");
	}
	
	public static void setDEK()
	{
		SettingsInfo info = _settingsdata;
		String dek = Security.buildDEK();
		info.setEncryptionKey(dek);
		_settingsdata = info;
		synchronized (settingsstore) {
			settingsstore.setContents(_settingsdata);
			settingsstore.commit();
		}
	}
	
	
	
	public static String getDEK()
	{
		synchronized (settingsstore) {
			_settingsdata = (SettingsInfo )settingsstore.getContents();
			if(!(_settingsdata == null))
			{
				SettingsInfo s = (SettingsInfo)_settingsdata;
				return s.getEncyptionKey();
			}
			return "";
		}
		
	}

	public static void setPhoneNumber(String phone) {
		SettingsInfo info = _settingsdata;
		String dek = Security.buildDEK();
		info.setPhoneNumber(phone);
		_settingsdata = info;
		synchronized (settingsstore) {
			settingsstore.setContents(_settingsdata);
			settingsstore.commit();
		}
	}
	
	public static String getPhoneNumber(){
		synchronized (settingsstore) {
			_settingsdata = (SettingsInfo )settingsstore.getContents();
			if(!(_settingsdata == null))
			{
				SettingsInfo s = (SettingsInfo)_settingsdata;
				return s.getPhoneNumber();
			}
			return null;
		}
	}
	
	
}
