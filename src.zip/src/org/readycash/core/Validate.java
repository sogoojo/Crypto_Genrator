package org.readycash.core;

public interface Validate {
	
	String getInvalidDataSummary();

}
